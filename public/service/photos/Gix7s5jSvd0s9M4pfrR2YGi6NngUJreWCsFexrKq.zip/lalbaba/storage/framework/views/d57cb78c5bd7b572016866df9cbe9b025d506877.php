<?php $__env->startSection('title', 'Product Details'); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>
    <div class="pagetitle">
        <h1>Product Tables</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo route ('admin.dashboard'); ?>">Home</a></li>
                <li class="breadcrumb-item">Product Show</li>
                <li class="breadcrumb-item active">Product Details</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <div class="card">
        <div class="card-header">
            <span class="font-weight-bold">Product Name :</span> <?php echo e($show->title); ?>

        </div>
        <div class="card-body">
            <div class="row my-3">
                <div class="col-sm-12 col-md-5 col-lg-5 text-center">
                    <h3>Product Image: </h3>
                    <img src="<?php echo e(asset($show->image)); ?>" height="auto" width="100%" alt="">
                </div>
                <div class="col-sm-12 col-md-7 col-lg-7">
                    <h3>Product Info: </h3>
                    <span> <b>Name : </b> <?php echo e($show->name); ?> </span><br>
                    <span> <b>Category Name : </b> <?php echo e($show->category_name); ?> </span><br>
                    <span> <b>Price : </b> <?php echo e($show->price); ?> </span><br>
                    <span> <b>Delivery : </b> <?php echo e($show->type); ?> </span><br>
                    <span> <b>Description : </b> <?php echo $show->body; ?> </span><br>
                </div>
            </div>
        </div>
    </div>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/admin/modules/product/show.blade.php ENDPATH**/ ?>