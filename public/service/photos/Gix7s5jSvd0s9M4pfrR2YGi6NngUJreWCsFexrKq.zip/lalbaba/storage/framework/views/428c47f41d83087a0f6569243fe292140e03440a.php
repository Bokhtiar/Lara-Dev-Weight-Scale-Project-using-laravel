<!DOCTYPE html>
<html>
<head>
    <title>lalbaba</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <p> Verify Email Code Is: <?php echo e($details['VerifyCode']); ?></p>
    <p>This Code For Password  </p>
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/emails/verifyEmailCode.blade.php ENDPATH**/ ?>