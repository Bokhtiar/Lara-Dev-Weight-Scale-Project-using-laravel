<!DOCTYPE html>
<html>
<head>
    <title>Lalbaba</title>
</head>
<body>
    <h1><?php echo e($welcome['title']); ?></h1>
    <p><?php echo e($welcome['body']); ?></p>
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/emails/welcome.blade.php ENDPATH**/ ?>