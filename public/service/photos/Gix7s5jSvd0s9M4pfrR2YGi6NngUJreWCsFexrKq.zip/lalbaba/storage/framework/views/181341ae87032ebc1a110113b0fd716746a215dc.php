<?php $__env->startSection('title', 'List Of Order'); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .zoom:hover {
            transform: scale(2.5);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>

    <div class="pagetitle">
        <h1>Order Tables</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo route ('admin.dashboard'); ?>">Home</a></li>
                <li class="breadcrumb-item">Tables</li>
                <li class="breadcrumb-item active">Order Table</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-header">
                        <?php if (isset($component)) { $__componentOriginalc38fa723bbde1cde1a8279f40704f35cdf16b365 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Notification::class, []); ?>
<?php $component->withName('notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc38fa723bbde1cde1a8279f40704f35cdf16b365)): ?>
<?php $component = $__componentOriginalc38fa723bbde1cde1a8279f40704f35cdf16b365; ?>
<?php unset($__componentOriginalc38fa723bbde1cde1a8279f40704f35cdf16b365); ?>
<?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Order Table  <a class="btn btn-sm btn-success" href=""> <i class="ri-add-box-line"></i> </a>  </h5>

                        <!-- Table with stripped rows -->
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th scope="col">SL</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">E-mail</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index + 1); ?></th>
                                        <td><?php echo e($item->f_name .''. $item->l_name); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->phone); ?></td>
                                        <td><?php echo e($item->type); ?></td>
                                        <td>
                                            <?php if($item->status == 1): ?>
                                                <a class="btn btn-sm btn-success" href="<?php echo route ('admin.order.status', $item->order_id); ?>"><i
                                                        class="bi bi-check-circle"></i></a>
                                            <?php else: ?>
                                                <a class="btn btn-warning btn-sm" href="<?php echo route ('admin.order.status', $item->order_id); ?>"><i
                                                        class="bi bi-exclamation-triangle"></i></a>
                                            <?php endif; ?>
                                        </td>
                                        <td class="form-inline">
                                            <a class="btn btn-sm btn-info text-light" href="<?php echo route ('admin.order.show', $item->order_id); ?>"> <i
                                                class="ri-eye-fill"></i></a>
                                            <form method="POST" action="<?php echo route ('admin.order.destroy',$item->order_id); ?>" class="mt-1">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('Delete'); ?>
                                                <button class="btn btn-sm btn-danger" type="submit"> <i
                                                    class="ri-delete-bin-6-fill"></i></button>
                                            </form>


                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <h2 class="bg-danger text-light text-center">order Is empty</h2>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

    <?php $__env->startSection('js'); ?>
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/admin/modules/order/index.blade.php ENDPATH**/ ?>