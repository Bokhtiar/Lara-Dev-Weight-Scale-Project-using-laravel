<?php $__env->startSection('title',  @edit ? 'Sub Category Update' : 'Sub Category Create' ); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .zoom:hover {
            transform: scale(2.5);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>

    <div class="pagetitle">
        <h1>Sub Category <?php echo e(@$edit ? 'Update' : 'Create'); ?> Form</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo route ('admin.dashboard'); ?>">Home</a></li>
                <li class="breadcrumb-item">Sub Category</li>
                <li class="breadcrumb-item active">Sub Category <?php echo e(@$edit ? 'Update' : 'Create'); ?> Form</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->


    <div class="card">
        <div class="card-header">
            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            
        </div>
        <div class="card-body">
            <h5 class="card-title">Sub Category <?php echo e(@$edit ? 'Update' : 'Create'); ?> Form <a href="<?php echo route ('admin.subcategory.index'); ?>" class="btn btn-sm btn-success"><i class="ri-list-unordered"></i></a></h5>
            <?php if(@$edit): ?>
                <form action="<?php echo route ('admin.subcategory.update', @$edit->sub_category_id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                <?php else: ?>
                    <form action="<?php echo route ('admin.subcategory.store'); ?>" method="post" enctype="multipart/form-data">
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <section class="form-group row">
                <div class="col-md-6 col-lg-6 my-2">
                    <label for="" class="form-label">Sub Category Name <span class="text-danger">*</span></label>
                    <input required type="text" class="form-control" name="name" value="<?php echo e(@$edit->name); ?>"
                        placeholder="type here Sub Category Name">
                </div>

                <div class="col-md-6 col-lg-6 my-2">
                    <label for="">Select Category <span class="text-danger">*</span></label>
                    <select class="form-control" name="category_id" id="">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->category_id); ?>"<?php echo e($cat->category_id == @$edit->category_id ? 'Selected' : ""); ?>><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-12 col-lg-12 my-2">
                    <label for="" class="form-label">Sub Category Image <span class="text-danger">*</span></label>
                    <input  <?php echo e(@$edit ? '' : 'required'); ?>  type="file" name="image" multiple class="form-control">
                    <?php if(isset($edit)): ?>
                    <div class="my-2">
                        <label for="">Already Image Seleted</label>
                        <img src="<?php echo e(asset($edit->image)); ?>" height="40px" width="40px" alt="">
                    </div>
                    <?php endif; ?>
                </div>
            </section>
            <br><br><br>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
            </form><!-- End Multi Columns Form -->

        </div>
    </div>


<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/admin/modules/subcategory/createOrUpdate.blade.php ENDPATH**/ ?>