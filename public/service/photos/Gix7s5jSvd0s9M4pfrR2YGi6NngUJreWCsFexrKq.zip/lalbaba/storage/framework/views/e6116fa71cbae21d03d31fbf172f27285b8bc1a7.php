<div>
    <?php if(Session::has('success')): ?>
        <div class="bg-success text-light alert alert-success">
            <i class="fa fa-check" aria-hidden="true"></i> <?php echo e(Session::get('success')); ?>

            <?php
                Session::forget('success');
            ?>
        </div>
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
        <div class="bg-warning text-light alert alert-success">
            <i class="fa fa-spin fa-refresh"></i> <?php echo e(Session::get('warning')); ?>

            <?php
                Session::forget('warning');
            ?>
        </div>
    <?php endif; ?>


    <?php if(Session::has('info')): ?>
        <div class="bg-info text-light alert alert-success">
            <i class="fa fa-check" aria-hidden="true"></i> <?php echo e(Session::get('info')); ?>

            <?php
                Session::forget('info');
            ?>
        </div>
    <?php endif; ?>
</div>

<?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/components/notification.blade.php ENDPATH**/ ?>