
home page <br>
<?php if(Auth::check()): ?>
<a class="btn btn-success" href="<?php echo route ('admin.dashboard'); ?>">DASHBOARD</a>
<?php else: ?>
<a class="btn btn-info text-light" href="<?php echo route ('login'); ?>">Login</a>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/welcome.blade.php ENDPATH**/ ?>