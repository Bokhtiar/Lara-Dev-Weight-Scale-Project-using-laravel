<?php $__env->startSection('title', @$edit ? 'Product Update' : 'Product Create'); ?>

<?php $__env->startSection('css'); ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style>
        .zoom:hover {
            transform: scale(2.5);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_content'); ?>

    <div class="pagetitle">
        <h1>Product <?php echo e(@$edit ? 'Update' : 'Create'); ?> Form</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo route ('admin.dashboard'); ?>">Home</a></li>
                <li class="breadcrumb-item">Product</li>
                <li class="breadcrumb-item active">Product <?php echo e(@$edit ? 'Update' : 'Create'); ?> Form</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->


    <div class="card">
        <div class="card-header">
            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            
        </div>
        <div class="card-body">
            <h5 class="card-title">Product <?php echo e(@$edit ? 'Update' : 'Create'); ?> Form <a href="<?php echo route ('admin.product.index'); ?>"
                    class="btn btn-sm btn-success"><i class="ri-list-unordered"></i></a></h5>
            <?php if(@$edit): ?>
                <form action="<?php echo route ('admin.product.update', @$edit->product_id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                <?php else: ?>
                    <form action="<?php echo route ('admin.product.store'); ?>" method="post" enctype="multipart/form-data">
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <section class="form-group row">



                



                <div class="col-md-12 col-lg-12 my-2">
                    <label for="" class="form-label">Product Name <span class="text-danger">*</span></label>
                    <input required type="text" class="form-control" name="name" value="<?php echo e(@$edit->name); ?>"
                        placeholder="type here Product Name">
                </div>


                <div class="col-sm-12 col-md-6 col-lg-6">
                    <label class="form-label" for="">Select Category</label>
                    <select name="category_id" class="form-control" id="">
                        <option value="">--select category--</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->category_id); ?>"
                                <?php echo e($cat->category_id == @$edit->category_id ? 'selected' : ''); ?>><?php echo e($cat->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-sm-12 col-md-6 col-lg-6">
                    <label class="form-label" for="">Select SubCategory </label>
                    <select name="subcategory_id" class="form-control" id="">
                        <option value="">--select SubCategory--</option>
                        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sub->sub_category_id); ?>"
                                <?php echo e($sub->subcategory_id == @$edit->subcategory_id ? 'selected' : ''); ?>><?php echo e($sub->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-sm-12 col-md-6 col-lg-6 my-2">
                    <label for="" class="form-label">Product Regular Price <span class="text-danger">*</span></label>
                    <input required type="text" class="form-control" name="regular_price" value="<?php echo e(@$edit->regular_price); ?>"
                        placeholder="type here Product Regular Price">
                </div>


                <div class="col-sm-12 col-md-6 col-lg-6 my-2">
                    <label for="" class="form-label">Product Discount Price </label>
                    <input  type="text" class="form-control" name="discount_price" value="<?php echo e(@$edit->discount_price); ?>"
                        placeholder="type here Product Discount Price">
                </div>

                <div class="col-sm-12 col-md-4 col-lg-4 my-2">
                    <label for="" class="form-label">Product Discount Percent </label>
                    <input  type="text" class="form-control" name="discount_percent" value="<?php echo e(@$edit->discount_percent); ?>"
                        placeholder="type here Product Discount Percent">
                </div>
                
                <div class="col-sm-12 col-md- col-lg-6 my-2">
                    <label for="" class="form-label">Product Discount Tag </label>
                    <input  type="text" class="form-control" name="discount_tag" value="<?php echo e(@$edit->discount_tag); ?>"
                        placeholder="type here Product Discount Tag">
                </div>


                <div class="col-sm-12 col-md-12 col-lg-12">
                    <label class="form-label" for="">Select Unit</label>
                    <select name="product_unit" class="form-control" id="">
                        <option value="">--select Unit--</option>
                        <option value="kg" <?php echo e(@$edit->product_unit == 'kg' ? 'selected' : ''); ?>>KG</option>
                        <option value="gm" <?php echo e(@$edit->product_unit == 'gm' ? 'selected' : ''); ?>>GM</option>
                        <option value="pc" <?php echo e(@$edit->product_unit == 'pc' ? 'selected' : ''); ?>>PC</option>
                    </select>
                </div>


                <div class="col-md-4 col-lg-4 my-2">
                    <label for="" class="form-label">Product Image <span class="text-danger">*</span></label>
                    <input <?php echo e(@$edit ? '' : 'required'); ?> type="file" name="image" multiple class="form-control">
                    <?php if(isset($edit)): ?>
                        <div class="my-2">
                            <label for="">Already Image1 Seleted</label>
                            <img src="<?php echo e(asset($edit->image)); ?>" height="40px" width="40px" alt="">
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-sm-12 col-md-8 col-lg-8 my-2">
                    <label class="form-label" for="">Select Delevery Process</label>
                    <select name="type" class="form-control" id="">
                        <option value="express" <?php echo e(@$edit->type == 'express' ? 'selected' : ''); ?>>Express Delivery
                        </option>
                        <option value="24/7" <?php echo e(@$edit->type == '24/7' ? 'selected' : ''); ?>>24/7 Delivery</option>
                    </select>
                </div>

                <div class="col-sm-12 col-md-6 col-lg-6 my-2">
                    <label for="" class="form-label">Product Quantity <span class="text-danger">*</span></label>
                    <input required type="number" class="form-control" name="quantity" value="<?php echo e(@$edit->quantity); ?>"
                        placeholder="type here Product Quantity">
                </div>


                <div class="col-sm-12 col-md-6 col-lg-6 my-2">
                    <label for="" class="form-label">Product Alert Quantity <span class="text-danger">*</span></label>
                    <input required type="text" class="form-control" name="alert_quantity" value="<?php echo e(@$edit->alert_quantity); ?>"
                        placeholder="type here Product Alert Quantity">
                </div>



                <div class="col-md-12 col-lg-12">
                    <label for="">Product Body <span class="text-danger">*</span></label>
                    <textarea name="body" class="form-control" cols="5" rows="10">
                       <?php echo @$edit->body; ?>

                      </textarea><!-- End TinyMCE Editor -->
                </div>
            </section>
            <br><br><br>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="reset" class="btn btn-secondary">Reset</button>
            </div>
            </form><!-- End Multi Columns Form -->

        </div>
    </div>


<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/admin/modules/product/createOrUpdate.blade.php ENDPATH**/ ?>