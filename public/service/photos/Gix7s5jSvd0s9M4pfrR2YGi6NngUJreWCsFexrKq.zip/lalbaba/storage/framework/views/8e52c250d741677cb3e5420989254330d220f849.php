<!DOCTYPE html>
<html>
<head>
    <title>lalbaba</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
    <p> New Password Is: <?php echo e($details['newPassword']); ?></p>
    <p>you can change your password go to setting then update your password </p>
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/emails/PasswordReset.blade.php ENDPATH**/ ?>