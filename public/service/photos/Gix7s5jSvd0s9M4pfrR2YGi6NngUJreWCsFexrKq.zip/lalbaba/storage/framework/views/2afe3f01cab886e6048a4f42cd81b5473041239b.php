<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>LalBaba</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
    </div>
  </footer>
<?php /**PATH C:\xampp\htdocs\lalbaba\lalbaba\lalbaba\resources\views/layouts/admin/partial/footer.blade.php ENDPATH**/ ?>