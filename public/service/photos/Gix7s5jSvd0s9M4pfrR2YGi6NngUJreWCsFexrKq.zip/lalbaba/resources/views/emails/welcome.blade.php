<!DOCTYPE html>
<html>
<head>
    <title>Lalbaba</title>
</head>
<body>
    <h1>{{ $welcome['title'] }}</h1>
    <p>{{ $welcome['body'] }}</p>
    <p>Thank you</p>
</body>
</html>