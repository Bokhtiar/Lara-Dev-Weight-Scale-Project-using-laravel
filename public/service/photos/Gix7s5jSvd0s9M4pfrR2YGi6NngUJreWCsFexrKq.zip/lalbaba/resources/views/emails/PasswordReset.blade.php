<!DOCTYPE html>
<html>
<head>
    <title>lalbaba</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
    <p> New Password Is: {{ $details['newPassword'] }}</p>
    <p>you can change your password go to setting then update your password </p>
    <p>Thank you</p>
</body>
</html>