<!DOCTYPE html>
<html>
<head>
    <title>lalbaba</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
    <p> Verify Email Code Is: {{ $details['VerifyCode'] }}</p>
    <p>This Code For Password  </p>
    <p>Thank you</p>
</body>
</html>